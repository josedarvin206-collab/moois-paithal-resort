MOOIS PAITHAL RESORT — WEBSITE PACKAGE

PROJECT STRUCTURE
- index.html — page content, SEO metadata and structured data
- assets/css/style.css — responsive page styling
- assets/js/main.js — date validation and WhatsApp enquiry form
- images/ — add your own approved resort photographs here

PREVIEW
1. Extract the ZIP file.
2. Open index.html in a modern browser.
3. Keep the assets folder in the same project directory.

ADD YOUR PHOTOGRAPHS
The project intentionally contains no stock photos or remotely hosted property photos.
Image areas currently display neutral placeholders.

For the About and Stay sections:
1. Copy your photo into images/, for example images/resort-about.jpg.
2. In index.html, find the relevant element with class="image-placeholder".
3. Replace that placeholder div with:
   <img src="images/resort-about.jpg" alt="Describe the resort photo" loading="lazy">

For the Gallery:
Repeat the same process for each gallery placeholder, using a different image filename and accurate alt text.

For the Hero background:
1. Add a photo such as images/hero.jpg.
2. In assets/css/style.css, find the .hero rule.
3. Add this background layer after the existing gradient:
   ,url('../../images/hero.jpg') center/cover no-repeat
   (Keep the existing gradient layer before the image layer.)

WHATSAPP ENQUIRIES
The enquiry form validates the dates and opens WhatsApp with a pre-filled message to:
+91 90724 95909
The form does not store submissions in a database and does not confirm reservations.

BEFORE PUBLISHING
- Verify the resort name, address, phone number, coordinates and all facilities.
- Confirm room types, rates, capacities, opening status and activity availability.
- Add only photos owned by the resort or approved for use.
- Add your verified domain and social sharing image when available.
- Connect analytics and advertising pixels only after obtaining the correct IDs and configuring consent requirements.

The page uses Google Fonts from Google Fonts. All property image locations are local placeholders; no third-party image URLs are included.
